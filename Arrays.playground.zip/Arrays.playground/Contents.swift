import UIKit

var someInts = [Int]()

someInts.append (10)

print("My array has \(10) items.")

print("My favorite things include \(10) items.")

var favoriteThings: [String] = ["Bow","Laptop"]


favoriteThings.append("Iphone 11")

favoriteThings += ["Watch"]
favoriteThings += ["keyboard","baseball glove","gym shoes","backpack","cap","wallet" ]

var firstItem = favoriteThings[0]

for item in favoriteThings {
    print(item)
}
